Including this readMe.txt file the zip file 
contains 2 files:

1) QSealC-NordeaDevPortal-2021.cer, and
2) QSealC-NordeaDevPortal-2021.p12

The p12 file includes the private key and 
pin for using it is 1111

The certificate is of type eIDAS QSEALC and can be used for testing connection
towards Nordea Developer Portal. 
It is used for testing the HTTP signature, not for identification of a party. 
ClientID & Secret are required.

The connection should be succesful with this certifiate but rejected if another certificate is used for signing. 

Note the expiration date of the certificate 
(Expires Dec 19 2021 serial nr 535dc422c38536a36e32e2e330c8e679)

By downloading and using it you accept to use these only for Nordea Development Portal and within EU/EEA only.


Nordea Bank Abp